#Mladen Rosenov Vasilev
#12/12/2018
#ISYS-497
#Professor Palmer

import pygame#import library pygame
from time import gmtime, strftime#import a specific function from time library
pygame.init()#initialize pygame funcionality

win = pygame.display.set_mode((1400,700))#parameters of window that we want to create stuff one
bg = pygame.image.load('bg.png')#background image
pygame.display.set_caption("First Game - Prototype")#name on the program tab


'''
Three colors
'''
BLACK = (0,0,0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

music = pygame.mixer.music.load('backgroundMusic.mp3')#background music
pygame.mixer.music.play(-1)#start music

clock = pygame.time.Clock()#clock in pygame
size = [1200,700]#list for size of screen
screen = pygame.display.set_mode(size)#size of screen
done = False#variable
score = 0#the user starts with score 0

class player(object):
    '''
    class that holds variables and controls of how the hero character
    we have lists with sprites that are used to draw the Hero
    each sprite list is located in the same foulder
    each sprite list has 7 objects inside of them
    '''
    
    #character left and right running
    walkLeft = [pygame.image.load('HeroRIGHT\_RUN_000.png'), pygame.image.load('HeroRIGHT\_RUN_001.png'), pygame.image.load('HeroRIGHT\_RUN_002.png'), pygame.image.load('HeroRIGHT\_RUN_003.png'), pygame.image.load('HeroRIGHT\_RUN_004.png'), pygame.image.load('HeroRIGHT\_RUN_005.png'), pygame.image.load('HeroRIGHT\_RUN_006.png')]
    walkRight = [pygame.image.load('HeroLEFT\_RUN_000.png'), pygame.image.load('HeroLEFT\_RUN_001.png'), pygame.image.load('HeroLEFT\_RUN_002.png'), pygame.image.load('HeroLEFT\_RUN_003.png'), pygame.image.load('HeroLEFT\_RUN_004.png'), pygame.image.load('HeroLEFT\_RUN_005.png'), pygame.image.load('HeroLEFT\_RUN_006.png')]

    #character standing idle left and right
    charRight = [pygame.image.load('HeroIDLE\_IDLE_000.png'), pygame.image.load('HeroIDLE\_IDLE_001.png'), pygame.image.load('HeroIDLE\_IDLE_002.png'), pygame.image.load('HeroIDLE\_IDLE_003.png'), pygame.image.load('HeroIDLE\_IDLE_004.png'), pygame.image.load('HeroIDLE\_IDLE_005.png'), pygame.image.load('HeroIDLE\_IDLE_006.png')]
    charLeft = [pygame.image.load('HeroIDLEleft\_IDLE_000.png'), pygame.image.load('HeroIDLEleft\_IDLE_001.png'), pygame.image.load('HeroIDLEleft\_IDLE_002.png'), pygame.image.load('HeroIDLEleft\_IDLE_003.png'), pygame.image.load('HeroIDLEleft\_IDLE_004.png'), pygame.image.load('HeroIDLEleft\_IDLE_005.png'), pygame.image.load('HeroIDLEleft\_IDLE_006.png')]

    #character Lancing left and right
    swordSlashRight = [pygame.image.load('Hero_ATTACK_Right\ATTACK_000.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_001.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_002.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_003.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_004.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_005.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
    swordSlashLeft = [pygame.image.load('Hero_ATTACK_LEFT\ATTACK_000.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_001.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_002.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_003.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_004.png'),pygame.image.load('Hero_ATTACK_LEFT\ATTACK_005.png'),pygame.image.load('Hero_ATTACK_LEFT\ATTACK_006.png')]

    #character is being hurt while standing Left and when standing right
    HeroHurtRight = [pygame.image.load('HeroHurtRight\_HURT_000.png'), pygame.image.load('HeroHurtRight\_HURT_001.png'), pygame.image.load('HeroHurtRight\_HURT_002.png'), pygame.image.load('HeroHurtRight\_HURT_003.png'), pygame.image.load('HeroHurtRight\_HURT_004.png'), pygame.image.load('HeroHurtRight\_HURT_005.png'), pygame.image.load('HeroHurtRight\_HURT_006.png')]
    HeroHurtLeft = [pygame.image.load('HeroHurtLeft\_HURT_000.png'), pygame.image.load('HeroHurtLeft\_HURT_001.png'), pygame.image.load('HeroHurtLeft\_HURT_002.png'), pygame.image.load('HeroHurtLeft\_HURT_003.png'), pygame.image.load('HeroHurtLeft\_HURT_004.png'), pygame.image.load('HeroHurtLeft\_HURT_005.png'), pygame.image.load('HeroHurtLeft\_HURT_006.png')]

    #character dying on the left side and character dying on the right side
    HeroDieRight = [pygame.image.load('HeroDieRight\_DIE_000.png'), pygame.image.load('HeroDieRight\_DIE_001.png'),pygame.image.load('HeroDieRight\_DIE_002.png'), pygame.image.load('HeroDieRight\_DIE_003.png'),pygame.image.load('HeroDieRight\_DIE_004.png'), pygame.image.load('HeroDieRight\_DIE_005.png'), pygame.image.load('HeroDieRight\_DIE_006.png')]
    HeroDieLeft = [pygame.image.load('HeroDieLeft\_DIE_000.png'), pygame.image.load('HeroDieLeft\_DIE_001.png'), pygame.image.load('HeroDieLeft\_DIE_002.png'), pygame.image.load('HeroDieLeft\_DIE_003.png'), pygame.image.load('HeroDieLeft\_DIE_004.png'), pygame.image.load('HeroDieLeft\_DIE_005.png'), pygame.image.load('HeroDieLeft\_DIE_006.png')] 

    
    def __init__(self,x,y,width,height):
        '''
        coordinates
        x is left and right
        y is up and down on the screen
        width is how wide we want our character to be, not our drawing
        height is how tall we want our character to be
        '''
        self.x = x
        self.y = y
        self.width = width
        self.height = height

        self.vel = 10#vel is how fast we want to be moving

        self.isJump = False#variable for jumping
        self.left = False#variable if we are facing left
        self.right = False#variable if we are facing right
        self.walkCount = 0#counts how many step we have taken so the sprite sheets can move as we are traveling throught the screen
        self.standing = True#variable if we are standing
        
        self.jumpCount = 10#variable that helps the jumping command
        
        '''
        slash is variable that states if we are hitting or not
        slashNumber counts on which sprite are we in the list
        '''
        self.slash = False
        self.slashNumber = 0

        self.hitbox = (self.x + 65, self.y + 25, 25, 80)#hitbox of character with coordinates
        self.hitboxAttack = (self.x, self.y + 60, 150, 20)#hitboxAttack coordinates

        self.hurt = False#variable is character hurt
        self.hurtNumber = -1#variable that keeps track on sprite sheets meant for character being hurt

        
        self.health = 3#health of character

        self.visible = True#are we visible on the screen
        self.die = False#are we dead
        self.dieNumber = 0#varible keeps the sprites going whenever character is dead

        self.HitboxVisible = False#this variable was meant for presentation so we can see the mechanincs whenever a hotkey is pressed
        

    def draw(self, win):
        self.hit()#calling the hit function because we want to check if we got hit or not
        
        if self.visible:#checks if our character is visible
            
            if self.walkCount + 1 >= 27:
                self.walkCount = 0#resets walkCount variable

            if self.slashNumber + 1 >= 20:
                self.slashNumber = 0#resets slashNumber
                self.slash = False#stops slashing

            if self.slash == True:
                '''
                if character is attacking go through here
                if character is left initiate left sprite sheets
                else character must be going with right sprite sheets
                every time it goes to each if/else statement
                we add an additional number in slashNumber
                '''
                
                if self.left != True:
                    win.blit(self.swordSlashRight[self.slashNumber%7], (self.x,self.y))
                    self.slashNumber += 1

                     
                else:
                    win.blit(self.swordSlashLeft[self.slashNumber%7], (self.x,self.y))
                    self.slashNumber += 1
                    
            elif self.hurt == True:
                '''
                if character is hurt
                we check which side he has is turned
                and intiate the appropriate sprite sheet lists
                '''
                
                if self.left != True:
                    win.blit(self.HeroHurtRight[self.hurtNumber], (self.x,self.y))

                else:
                    win.blit(self.HeroHurtLeft[self.hurtNumber], (self.x,self.y))

            elif not(self.standing):
                '''
                we are are not standing
                then check which side we are going
                and use the approapriate sprite sheet
                each path adds additional number so sprite sheets move within the list
                '''
                
                if self.left:
                    win.blit(self.walkLeft[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1
                    
                elif self.right:
                    win.blit(self.walkRight[self.walkCount//7], (self.x,self.y))
                    self.walkCount +=1
                    
            else:
                '''
                are we standing
                are we facing left and right
                and we used seconds to itirate the sprites within the sheet
                every second we change the sprite
                '''
                
                if self.right:
                    number = (int(strftime("%S", gmtime()))) % 7
                    win.blit(self.charRight[number], (self.x,self.y))
                    
                else:
                    number = (int(strftime("%S", gmtime()))) % 7
                    win.blit(self.charLeft[number], (self.x,self.y))

        elif self.die == True and self.dieNumber < 7:
            '''
            we check if hero is dead and if sprites are itirating
            '''
            
            if self.left != True:
                win.blit(self.HeroDieRight[self.dieNumber], (self.x,self.y))
                if self.dieNumber == 6:
                    self.die == False
            else:
                win.blit(self.HeroDieLeft[self.dieNumber], (self.x,self.y))
                if self.dieNumber == 6:
                   self.die == False

        else:
            '''
            if character die == False
            then we check which side the character has died on
            and leave the last sprite where the character is laying on the ground
            '''
            
            if self.left != True:
                win.blit(self.HeroDieRight[6], (self.x,self.y))

            else:
                win.blit(self.HeroDieLeft[6], (self.x,self.y))
        
        self.hitbox = (self.x + 65, self.y + 25, 25, 80)#keeps character hitbox following the character as he is walking on screen
        self.hitboxAttack = (self.x, self.y + 60, 150, 20)#keeps attack hitbox with character
        
        if self.HitboxVisible == True:#presentation purposes draws both hitbox when pressed hot key
            
            pygame.draw.rect(win, (255,0,0), self.hitbox, 2)
            pygame.draw.rect(win, (0,0,255), self.hitboxAttack, 2)
        
    def hit (self):
        '''
        hit function when hero is being hit
        the functions checks which side the character is facing
        if the character has health
        if character is dead
        we add 1 to dieNumber and then the sprite sheet itirates in the upper function
        '''
        if self.right == True and self.health == 0 and self.die == True:
            self.dieNumber += 1
                
        elif self.left == True and self.health == 0 and self.die == True:
           self.dieNumber += 1

        elif self.right == True and self.hurt == True:#are we hurt facing right
            self.hurtNumber += 1
            
            if self.hurtNumber > 6:
                self.hurtNumber = -1
                self.hurt = False
                self.x = self.x - 30#hero thrown back by 30 pixels
                
                if self.health > 0:
                    self.health -= 1#losing health

                else:#if no more health left then change variables for die and visible
                    self.visible = False
                    self.die = True
                
        elif self.left == True and self.hurt == True:#are we hurt facing left
            self.hurtNumber += 1
            
            if self.hurtNumber > 6:
                self.hurtNumber = -1
                self.hurt = False
                self.x = self.x + 30#hero thrown back by 30 pixels
                
                if self.health > 0:
                    self.health -= 1#losing health

                else:#if no more health left then change variables for die and visible
                    self.visible = False
                    self.die = True


    


class enemy(object):
    '''
    Enemy class
    '''

    #walking sprite sheets
    walkRight = [pygame.image.load('OrcRIGHT\RUN_000.png'), pygame.image.load('OrcRIGHT\RUN_001.png'), pygame.image.load('OrcRIGHT\RUN_002.png'), pygame.image.load('OrcRIGHT\RUN_003.png'), pygame.image.load('OrcRIGHT\RUN_004.png'), pygame.image.load('OrcRIGHT\RUN_005.png'), pygame.image.load('OrcRIGHT\RUN_006.png')]
    walkLeft = [pygame.image.load('OrcLEFT\RUN_000.png'), pygame.image.load('OrcLEFT\RUN_001.png'), pygame.image.load('OrcLEFT\RUN_002.png'), pygame.image.load('OrcLEFT\RUN_003.png'), pygame.image.load('OrcLEFT\RUN_004.png'), pygame.image.load('OrcLEFT\RUN_005.png'), pygame.image.load('OrcLEFT\RUN_006.png')]

    #enemy being hurt sprite sheets
    orcHurtLeft = [pygame.image.load('OrcHURTleft\HURT_000.png'), pygame.image.load('OrcHURTleft\HURT_001.png'), pygame.image.load('OrcHURTleft\HURT_002.png'), pygame.image.load('OrcHURTleft\HURT_003.png'), pygame.image.load('OrcHURTleft\HURT_004.png'), pygame.image.load('OrcHURTleft\HURT_005.png'), pygame.image.load('OrcHURTleft\HURT_006.png')]
    orcHurtRight = [pygame.image.load('OrcHURTright\HURT_000.png'), pygame.image.load('OrcHURTright\HURT_001.png'), pygame.image.load('OrcHURTright\HURT_002.png'), pygame.image.load('OrcHURTright\HURT_003.png'), pygame.image.load('OrcHURTright\HURT_004.png'), pygame.image.load('OrcHURTright\HURT_005.png'), pygame.image.load('OrcHURTright\HURT_006.png')]

    #enemy dying on right or left
    orcDieLeft = [pygame.image.load('OrcDieleft\DIE_000.png'), pygame.image.load('OrcDieleft\DIE_001.png'), pygame.image.load('OrcDieleft\DIE_002.png'), pygame.image.load('OrcDieleft\DIE_003.png'), pygame.image.load('OrcDieleft\DIE_004.png'), pygame.image.load('OrcDieleft\DIE_005.png'), pygame.image.load('OrcDieleft\DIE_006.png')]
    orcDieRight = [pygame.image.load('OrcDieright\DIE_000.png'), pygame.image.load('OrcDieright\DIE_001.png'), pygame.image.load('OrcDieright\DIE_002.png'), pygame.image.load('OrcDieright\DIE_003.png'), pygame.image.load('OrcDieright\DIE_004.png'), pygame.image.load('OrcDieright\DIE_005.png'), pygame.image.load('OrcDieright\DIE_006.png')]

    #enemy hitting left and right
    AxeSlashRight = [pygame.image.load('OrcAttackRight\ATTACK_000.png'), pygame.image.load('OrcAttackRight\ATTACK_001.png'), pygame.image.load('OrcAttackRight\ATTACK_002.png'), pygame.image.load('OrcAttackRight\ATTACK_003.png'), pygame.image.load('OrcAttackRight\ATTACK_004.png'), pygame.image.load('OrcAttackRight\ATTACK_005.png'), pygame.image.load('OrcAttackRight\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
    AxeSlashLeft = [pygame.image.load('OrcAttackLeft\ATTACK_000.png'), pygame.image.load('OrcAttackLeft\ATTACK_001.png'), pygame.image.load('OrcAttackLeft\ATTACK_002.png'), pygame.image.load('OrcAttackLeft\ATTACK_003.png'), pygame.image.load('OrcAttackLeft\ATTACK_004.png'),pygame.image.load('OrcAttackLeft\ATTACK_005.png'),pygame.image.load('OrcAttackLeft\ATTACK_006.png')]

    def __init__(self, x, y, width, height, end):
        '''
        variables
        x is left and right
        y is up and down
        how wide is the enemy
        height of the enemy
        path refers to the path that the enemy can walk back and forth
        walkCount keep track of steps of the enemy
        vel is the speed by which the enemy can travel to
        '''
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, end]
        self.walkCount = 0
        self.vel = 5

        self.hitbox = (self.x + 60, self.y + 5, 50, 50)#enemy hitbox parameters
        self.health = 3#health of enemy
        self.Troll = False#when True means that Troll is being used
        
        self.visible = True#is enemy visible
        self.die = False#is enemy dead
        self.dieNumber = -1#number which helps the list of sprites of the enemy dying
        
        self.hurt = False#is enemy hurt
        self.hurtNumber = -1#number for hurt sprites

        self.attack = False#is enemy attacking
        self.attackNumber = -1#number for attack sprites

        self.HitboxVisible = False#used for presentation so hitbox can be seen

    def draw(self, win):
        self.move()#we want allways to go through move function
        
        if self.visible:#is character visible
            
            if self.walkCount + 1 >= 33:
                self.walkCount = 0#reset walkCount
            
            if self.vel > 0:#is orc going forward
                
                if self.hurt == True:#is orc hurt
                    win.blit(self.orcHurtRight[self.hurtNumber], (self.x,self.y))
                    
                elif self.attack == True:#is orc attacking
                    if self.Troll == True:#is orc a troll
                        win.blit(self.AxeSlashRight[self.attackNumber], (self.x,self.y - 80))#troll sprite

                    else:
                        win.blit(self.AxeSlashRight[self.attackNumber], (self.x,self.y - 45))#orc sprite

                elif  self.health == 0 and self.die == True and self.dieNumber < 7:#is orc dead
                    win.blit(self.orcDieRight[self.dieNumber], (self.x,self.y))
                    self.dieNumber += 1
                    if self.dieNumber == 6:
                        self.dieNumber = -1
                        self.visible = False
                
                else:#is orc just walking right
                    win.blit(self.walkRight[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1
                    
            else:#if we are not going right then we are going left
                
                if self.hurt == True:#is enemy hurt
                    win.blit(self.orcHurtLeft[self.hurtNumber], (self.x,self.y))
                    
                    
                elif self.attack == True:#is enemy attacking
                    
                    if self.Troll == True:#is orc a Troll
                        win.blit(self.AxeSlashLeft[self.attackNumber], (self.x,self.y - 80))
                        
                    else:#is orc just an orc trying to strike
                        win.blit(self.AxeSlashLeft[self.attackNumber], (self.x,self.y - 45))

                elif  self.health == 0 and self.die == True and self.dieNumber < 7 :#is orc dying
                    win.blit(self.orcDieLeft[self.dieNumber], (self.x,self.y))
                    self.dieNumber += 1
                    
                    if self.dieNumber == 6:
                        self.dieNumber = -1
                        self.visible = False
                    
                else:#is the orc just trying to go left on the screen
                    win.blit(self.walkLeft[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1

            if self.Troll == False:#is an orc actually a Troll
                self.hitbox = (self.x + 60, self.y + 5, 50, 50)#enemy hitbox
                
                if self.HitboxVisible == True:#function for presentation Troll
                    pygame.draw.rect(win, (255,0,0), self.hitbox,2)
                

            else:
                self.hitbox = (self.x + 95, self.y + 25, 85, 150)#orc hitbox
                
                if self.HitboxVisible == True:#function for presentation Orc
                    pygame.draw.rect(win, (255,0,0), self.hitbox,2)

        else:
            
            if self.vel > 0:
                #enemy is laying on the ground dead right
                win.blit(self.orcDieRight[self.dieNumber], (self.x,self.y))

            else:
                #enemt is laying on the ground dead left
                win.blit(self.orcDieLeft[self.dieNumber], (self.x,self.y))
            

        
            
    def move(self):#move function
        if self.visible:#is enemy visible
            
            if self.vel > 0:#is enemy going right
                
                if self.x < self.path[1] + self.vel:
                    
                    if self.hurt == True and self.hurtNumber < 6:#is enemy hurt
                        self.hurtNumber +=1#changes sprites
                        
                        if self.Troll == True:#if enemy is troll do not have setback whenever hit
                            pass
                        
                        else:
                            self.x -= 10#goes back when hit
                        
                    elif self.attack == True and self.attackNumber < 6:#is enemy attacking
                        self.attackNumber +=1
                        
                    else:
                        '''
                        resets certain variables
                        '''
                        self.hurtNumber = -1
                        self.attackNumber = -1
                        self.hurt = False
                        self.attack = False
                        
                        self.x += self.vel#is enemy walking right
                        
                    
                else:
                    #turning around whenever path finishes on the right
                    self.vel = self.vel * -1
                    self.x += self.vel
                    self.walkCount = 0
                    
                    
            else:#is enemy going left
                if self.x > self.path[0] - self.vel:
                    
                    if self.hurt == True and self.hurtNumber < 6:#is enemy hurt
                        self.hurtNumber+=1#number itirates sprites in a list
                        
                        if self.Troll == True:#is enemy Troll
                            pass
                        
                        else:#is enemy regular Orc
                            self.x += 10
                        
                    elif self.attack == True and self.attackNumber < 6:#is enemy attacking
                        self.attackNumber +=1
                        
                    else:
                        '''
                        resets certain variables
                        '''
                        self.hurtNumber = -1
                        self.attackNumber = -1
                        self.hurt = False
                        self.attack = False
                        
                        self.x += self.vel#is enemy walking right
                    
                else:
                    #turning around whenever path finishes on the left
                    self.vel = self.vel * -1
                    self.x += self.vel
                    self.walkCount = 0
                    


    def hit(self):
        '''
        function that takes health from enemy
        '''
        if self.health > 0:
            self.health -= 1
            self.hurt = True
            
        else:
            self.die = True
            
        


def redrawGameWindow():
    '''
    function that put stuff on the display
    '''
    win.blit(bg, (0,0))#background picture
    text = font.render('Health: '+ str(man.health), 1, (0,0,0))
    win.blit(text, (50, 40))#up left health variable
    text = font.render('Score: '+ str(score), 1, (0,0,0))
    win.blit(text, (1000, 40))#up right Score variable
    man.draw(win)#drawing hero
    enemy1.draw(win)#drawing enemy
    enemy2.draw(win)#drawing enemy
    enemy3.draw(win)#drawing enemy
    enemy4.draw(win)#drawing enemy
    if man.HitboxVisible == True:#presentation reason
        enemy5.draw(win)#draw enemy
        
        if enemy5.die == False:  
            enemy5.visible = True
            
        else:
            pass
        
    elif enemy1.visible == False and enemy2.visible == False and enemy3.visible == False and enemy4.visible == False and man.HitboxVisible == False:#if everyone on screen is dead then draw Troll
        enemy5.draw(win)
        
        if enemy5.die == False:  
            enemy5.visible = True
            
        else:
            pass
    
    
    pygame.display.update()#update the screen

'''
next line specify the Troll enemy,
we have 5 variables
we turn on the Troll variable
then we change the sprite lists in the class with the Troll sheets
then we assign visible to False so the troll is not visible from the start of the game
I also wanted for the Troll to be a little bit slower so I changed the velocity of this character as well
'''
enemy5 = enemy(-400, 500, 64, 64, 1000)
enemy5.Troll = True
enemy5.health = 200
enemy5.orcDieRight = [pygame.image.load('TrollDieRight\DIE_000.png'), pygame.image.load('TrollDieRight\DIE_001.png'), pygame.image.load('TrollDieRight\DIE_002.png'), pygame.image.load('TrollDieRight\DIE_003.png'), pygame.image.load('TrollDieRight\DIE_004.png'), pygame.image.load('TrollDieRight\DIE_005.png'), pygame.image.load('TrollDieRight\DIE_006.png')]
enemy5.orcDieLeft = [pygame.image.load('TrollDieLeft\DIE_000.png'), pygame.image.load('TrollDieLeft\DIE_001.png'), pygame.image.load('TrollDieLeft\DIE_002.png'), pygame.image.load('TrollDieLeft\DIE_003.png'), pygame.image.load('TrollDieLeft\DIE_004.png'), pygame.image.load('TrollDieLeft\DIE_005.png'), pygame.image.load('TrollDieLeft\DIE_006.png')]
enemy5.AxeSlashRight = [pygame.image.load('TrollAttackRight\ATTACK_000.png'), pygame.image.load('TrollAttackRight\ATTACK_001.png'), pygame.image.load('TrollAttackRight\ATTACK_002.png'), pygame.image.load('TrollAttackRight\ATTACK_003.png'), pygame.image.load('TrollAttackRight\ATTACK_004.png'), pygame.image.load('TrollAttackRight\ATTACK_005.png'), pygame.image.load('TrollAttackRight\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
enemy5.AxeSlashLeft = [pygame.image.load('TrollAttackLeft\ATTACK_000.png'), pygame.image.load('TrollAttackLeft\ATTACK_001.png'), pygame.image.load('TrollAttackLeft\ATTACK_002.png'), pygame.image.load('TrollAttackLeft\ATTACK_003.png'), pygame.image.load('TrollAttackLeft\ATTACK_004.png'),pygame.image.load('TrollAttackLeft\ATTACK_005.png'),pygame.image.load('TrollAttackLeft\ATTACK_006.png')]
enemy5.orcHurtLeft = [pygame.image.load('TrollHurtLeft\HURT_000.png'), pygame.image.load('TrollHurtLeft\HURT_001.png'), pygame.image.load('TrollHurtLeft\HURT_002.png'), pygame.image.load('TrollHurtLeft\HURT_003.png'), pygame.image.load('TrollHurtLeft\HURT_004.png'), pygame.image.load('TrollHurtLeft\HURT_005.png'), pygame.image.load('TrollHurtLeft\HURT_006.png')]
enemy5.orcHurtRight = [pygame.image.load('TrollHurtRight\HURT_000.png'), pygame.image.load('TrollHurtRight\HURT_001.png'), pygame.image.load('TrollHurtRight\HURT_002.png'), pygame.image.load('TrollHurtRight\HURT_003.png'), pygame.image.load('TrollHurtRight\HURT_004.png'), pygame.image.load('TrollHurtRight\HURT_005.png'), pygame.image.load('TrollHurtRight\HURT_006.png')]
enemy5.walkRight = [pygame.image.load('TrollRunRight\RUN_000.png'), pygame.image.load('TrollRunRight\RUN_001.png'), pygame.image.load('TrollRunRight\RUN_002.png'), pygame.image.load('TrollRunRight\RUN_003.png'), pygame.image.load('TrollRunRight\RUN_004.png'), pygame.image.load('TrollRunRight\RUN_005.png'), pygame.image.load('TrollRunRight\RUN_006.png')]
enemy5.walkLeft = [pygame.image.load('TrollRunLeft\RUN_000.png'), pygame.image.load('TrollRunLeft\RUN_001.png'), pygame.image.load('TrollRunLeft\RUN_002.png'), pygame.image.load('TrollRunLeft\RUN_003.png'), pygame.image.load('TrollRunLeft\RUN_004.png'), pygame.image.load('TrollRunLeft\RUN_005.png'), pygame.image.load('TrollRunLeft\RUN_006.png')]
enemy5.visible = False
enemy5.vel = 4

font = pygame.font.SysFont('comicsans', 30, True, True)
man = player(500, 500, 64,64)#Hero place on screen

enemy1 = enemy(-50, 500, 64, 64, 1000)#enemy place on the screen.
enemy2 = enemy(-10, 550, 64, 64, 1000)#enemy place on the screen.
enemy3 = enemy(60, 560, 64, 64, 1000)#enemy place on the screen.
enemy4 = enemy(300, 600, 64, 64, 1000)#enemy place on the screen.



display_instructions = True
instruction_page = 1
run = True

while run and display_instructions:
    '''
    first loop that displays the first screen to the user
    '''
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            done = True
            
        if event.type == pygame.MOUSEBUTTONDOWN:
            instruction_page += 1
            
            if instruction_page == 2:
                display_instructions = False
 
    # Set the screen background
    screen.fill(BLACK)
 
    if instruction_page == 1:
 
        text = font.render("Moe's Game", True, WHITE)#text
        screen.blit(text, [10, 10])#where to be positioned

        text = font.render('Press "q" if you want to exit the Game', True, WHITE)#text
        screen.blit(text, [10, 50])#where to be positioned
 
        text = font.render("Welcome to the Middle ages in MOLANDIA.", True, WHITE)#text
        screen.blit(text, [350, 300])#where to be positioned

        text = font.render("Press mousepad to continue.", True, WHITE)#text
        screen.blit(text, [425, 450])#where to be positioned
 
 
    
    clock.tick(60)# Limit to 60 frames per second
 
    pygame.display.flip()


FirstTimeRun = True#variable

'''
Main Loop
'''
while run:
    '''
    loop that runs the game
    '''
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            run = False
    clock.tick(27)#how fast is the game running

    if FirstTimeRun == True:
            #this statement is a splash screen
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('SLAY!!!', 1, (255,0,0))
            win.blit(text, [470, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(7)
                i += 1
                FirstTimeRun = False#this ensures that this is run only once
                
        
    if enemy1.visible != False and enemy1.die != True:#if enemy alive
        
        if man.die == False:#if hero alive
            
            if man.hitbox[1] < man.hitbox[1] + enemy1.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy1.hitbox[1]:#if x of enemy is in x of hero then
                
                if man.hitbox[0] < enemy1.hitbox[0] + enemy1.hitbox[2] and man.hitbox[0] + man.hitbox[2] > enemy1.hitbox[0]:#if y of enemy is in y of hero then
                    enemy1.attack = True#enemy attack animation
                    man.hurt = True#hero is hurt
                    score -= 5


    if enemy2.visible != False and enemy2.die != True:#if enemy alive
        
        if man.die == False:#if hero alive
            
            if man.hitbox[1] < man.hitbox[1] + enemy2.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy2.hitbox[1]:#if x of enemy is in x of hero then
                
                if man.hitbox[0] + man.hitbox[2] > enemy2.hitbox[0] and man.hitbox[0] < enemy2.hitbox[0] + enemy2.hitbox[2]:#if y of enemy is in y of hero then
                    enemy2.attack = True#enemy attack animation
                    man.hurt = True#hero is hurt
                    score -= 5

    if enemy3.visible != False and enemy3.die != True:#if enemy alive
        
        if man.die == False:#if hero alive
            
            if man.hitbox[1] < man.hitbox[1] + enemy3.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy3.hitbox[1]:#if x of enemy is in x of hero then
                
                if man.hitbox[0] + man.hitbox[2] > enemy3.hitbox[0] and man.hitbox[0] < enemy3.hitbox[0] + enemy3.hitbox[2]:#if y of enemy is in y of hero then                 
                    enemy3.attack = True#enemy attack animation
                    man.hurt = True#hero is hurt
                    score -= 5

    if enemy4.visible != False and enemy4.die != True:#if enemy alive
        
        if man.die == False:#if hero alive
            
            if man.hitbox[1] < man.hitbox[1] + enemy4.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy4.hitbox[1]:#if x of enemy is in x of hero then
                
                if man.hitbox[0] + man.hitbox[2] > enemy4.hitbox[0] and man.hitbox[0] < enemy4.hitbox[0] + enemy4.hitbox[2]:#if y of enemy is in y of hero then
                    enemy4.attack = True#enemy attack animation
                    man.hurt = True#hero is hurt
                    score -= 5

    if enemy5.visible != False and enemy5.die != True:#if enemy alive
        
        if man.die == False:#if hero alive
            
            if man.hitbox[1] < man.hitbox[1] + enemy5.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy5.hitbox[1]:#if x of enemy is in x of hero then
                
                if man.hitbox[0] + man.hitbox[2] > enemy5.hitbox[0] and man.hitbox[0] < enemy5.hitbox[0] + enemy5.hitbox[2]:#if y of enemy is in y of hero then
                    enemy5.attack = True#enemy attack animation
                    man.hurt = True#hero is hurt
                    score -= 5

    
        
    
            
    keys = pygame.key.get_pressed()

    if keys[pygame.K_x]:# if "x" is pressed then
        man.slash = True#trigger animation of man hitting

        if man.die == False:#if hero not dead
            
            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy1.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy1.hitbox[1]:#if x of hero is in x of enemy
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy1.hitbox[0] and man.hitboxAttack[0] < enemy1.hitbox[0] + enemy1.hitbox[2]:#if y of hero is in y of enemy
                    enemy1.hit()#enemy is hurt
                    '''
                    if health is 0 then pass
                    if health is more than 0 then score
                    '''
                    
                    if enemy1.health == 0:
                        pass
                    
                    else:
                        score += 1 

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy2.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy2.hitbox[1]:#if x of hero is in x of enemy
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy2.hitbox[0] and man.hitboxAttack[0] < enemy2.hitbox[0] + enemy2.hitbox[2]:#if y of hero is in y of enemy
                    enemy2.hit()#enemy is hurt
                    '''
                    if health is 0 then pass
                    if health is more than 0 then score
                    '''
                    
                    if enemy2.health == 0:
                        pass
                    
                    else:
                        score += 1

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy3.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy3.hitbox[1]:#if x of hero is in x of enemy
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy3.hitbox[0] and man.hitboxAttack[0] < enemy3.hitbox[0] + enemy3.hitbox[2]:#if y of hero is in y of enemy
                    enemy3.hit()#enemy is hurt
                    '''
                    if health is 0 then pass
                    if health is more than 0 then score
                    '''

                    if enemy3.health == 0:
                        pass
                    
                    else:
                        score += 1
                        
            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy4.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy4.hitbox[1]:#if x of hero is in x of enemy
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy4.hitbox[0] and man.hitboxAttack[0] < enemy4.hitbox[0] + enemy4.hitbox[2]:#if y of hero is in y of enemy
                    enemy4.hit()#enemy is hurt
                    '''
                    if health is 0 then pass
                    if health is more than 0 then score
                    '''
                    
                    if enemy4.health == 0:
                        pass
                    
                    else:
                        score += 1

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy5.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy5.hitbox[1]:#if x of hero is in x of enemy
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy5.hitbox[0] and man.hitboxAttack[0] < enemy5.hitbox[0] + enemy5.hitbox[2]:#if y of hero is in y of enemy
                    enemy5.hit()#enemy is hurt
                    '''
                    if health is 0 then pass
                    if health is more than 0 then score
                    '''
                    
                    if enemy5.health == 0:
                        pass
                    
                    else:
                        score += 1


    if keys[pygame.K_LEFT] and man.x >  man.vel:#if left key arrow go left
        man.x -= man.vel
        man.left = True
        man.right = False
        man.standing = False
        
    elif keys[pygame.K_RIGHT] and man.x < 1100 - man.width - man.vel:#if right key arrow go right
        man.x += man.vel
        man.right = True
        man.left = False
        man.standing = False

    elif keys[pygame.K_UP] and man.y > man.vel and man.y > 550 - man.width - man.vel:#if up arrow then go up
        man.y -= man.vel
        '''
        check which side it was last moving so hero animation can be consistent
        '''
        if man.right == True:
            man.right = True
            man.left = False
            man.standing = False

        else:
            man.left = True
            man.right = False
            man.standing = False
        
    elif keys[pygame.K_DOWN] and man.y > man.vel and man.y < 670 - man.width - man.vel:#if down arrow then go down
        man.y += man.vel
        '''
        check which side it was last moving so hero animation can be consistent
        '''
        
        if man.right == True:
            man.right = True
            man.left = False
            man.standing = False

        else:
            man.left = True
            man.right = False
            man.standing = False

    elif keys[pygame.K_p]:#presentation purposes, "p" revives everybody who is dead
        
        for i in (enemy1,enemy2,enemy3,enemy4,enemy5,man):

            if i.visible == False:
                i.health = 10
                i.visible = True
                i.die = False
                i.HitboxVisible = True

    elif keys[pygame.K_q]:#exits game
        
        if score <= 0:
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('You can do better', 1, (255,0,0))#if you score less than 0 
            win.blit(text, [280, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(3000)
                i += 1
                pygame.quit()
                
        else:
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('Well done', 1, (255,0,0))#if you score more than 0 
            win.blit(text, [470, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(3000)
                i += 1
                pygame.quit()
        
        
    
    else:#if noting is going on then stand
        man.standing = True
        man.walkCount = 0

    if not(man.isJump):
        if keys[pygame.K_SPACE]:#if spacebar pressed jump
            man.isJump = True
            man.right = False
            man.left = False
            man.walkCount = 0
    else:
        '''
        equation for hero jumping
        '''
        if man.jumpCount >= -10:
            neg = 1
            
            if man.jumpCount < 0:
                neg = -1
                
            man.y -= (man.jumpCount ** 2) * 0.5 * neg
            man.jumpCount -= 1
            
        else:
            man.isJump = False
            man.jumpCount = 10
            
    redrawGameWindow()#update screen everytime it loops

pygame.quit()


