#Mladen Rosenov Vasilev
#12/12/2018
#ISYS-497
#Professor Palmer

import pygame
from time import gmtime, strftime
pygame.init()

win = pygame.display.set_mode((1400,700))
bg = pygame.image.load('bg.png')
pygame.display.set_caption("First Game - Prototype")

BLACK = (0,0,0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

music = pygame.mixer.music.load('backgroundMusic.mp3')
pygame.mixer.music.play(-1)

clock = pygame.time.Clock()
size = [1200,700]
screen = pygame.display.set_mode(size)
done = False
score = 0

class player(object):
    walkLeft = [pygame.image.load('HeroRIGHT\_RUN_000.png'), pygame.image.load('HeroRIGHT\_RUN_001.png'), pygame.image.load('HeroRIGHT\_RUN_002.png'), pygame.image.load('HeroRIGHT\_RUN_003.png'), pygame.image.load('HeroRIGHT\_RUN_004.png'), pygame.image.load('HeroRIGHT\_RUN_005.png'), pygame.image.load('HeroRIGHT\_RUN_006.png')]
    walkRight = [pygame.image.load('HeroLEFT\_RUN_000.png'), pygame.image.load('HeroLEFT\_RUN_001.png'), pygame.image.load('HeroLEFT\_RUN_002.png'), pygame.image.load('HeroLEFT\_RUN_003.png'), pygame.image.load('HeroLEFT\_RUN_004.png'), pygame.image.load('HeroLEFT\_RUN_005.png'), pygame.image.load('HeroLEFT\_RUN_006.png')]

    charRight = [pygame.image.load('HeroIDLE\_IDLE_000.png'), pygame.image.load('HeroIDLE\_IDLE_001.png'), pygame.image.load('HeroIDLE\_IDLE_002.png'), pygame.image.load('HeroIDLE\_IDLE_003.png'), pygame.image.load('HeroIDLE\_IDLE_004.png'), pygame.image.load('HeroIDLE\_IDLE_005.png'), pygame.image.load('HeroIDLE\_IDLE_006.png')]
    charLeft = [pygame.image.load('HeroIDLEleft\_IDLE_000.png'), pygame.image.load('HeroIDLEleft\_IDLE_001.png'), pygame.image.load('HeroIDLEleft\_IDLE_002.png'), pygame.image.load('HeroIDLEleft\_IDLE_003.png'), pygame.image.load('HeroIDLEleft\_IDLE_004.png'), pygame.image.load('HeroIDLEleft\_IDLE_005.png'), pygame.image.load('HeroIDLEleft\_IDLE_006.png')]

    swordSlashRight = [pygame.image.load('Hero_ATTACK_Right\ATTACK_000.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_001.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_002.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_003.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_004.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_005.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
    swordSlashLeft = [pygame.image.load('Hero_ATTACK_LEFT\ATTACK_000.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_001.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_002.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_003.png'), pygame.image.load('Hero_ATTACK_LEFT\ATTACK_004.png'),pygame.image.load('Hero_ATTACK_LEFT\ATTACK_005.png'),pygame.image.load('Hero_ATTACK_LEFT\ATTACK_006.png')]

    HeroHurtRight = [pygame.image.load('HeroHurtRight\_HURT_000.png'), pygame.image.load('HeroHurtRight\_HURT_001.png'), pygame.image.load('HeroHurtRight\_HURT_002.png'), pygame.image.load('HeroHurtRight\_HURT_003.png'), pygame.image.load('HeroHurtRight\_HURT_004.png'), pygame.image.load('HeroHurtRight\_HURT_005.png'), pygame.image.load('HeroHurtRight\_HURT_006.png')]
    HeroHurtLeft = [pygame.image.load('HeroHurtLeft\_HURT_000.png'), pygame.image.load('HeroHurtLeft\_HURT_001.png'), pygame.image.load('HeroHurtLeft\_HURT_002.png'), pygame.image.load('HeroHurtLeft\_HURT_003.png'), pygame.image.load('HeroHurtLeft\_HURT_004.png'), pygame.image.load('HeroHurtLeft\_HURT_005.png'), pygame.image.load('HeroHurtLeft\_HURT_006.png')]

    HeroDieRight = [pygame.image.load('HeroDieRight\_DIE_000.png'), pygame.image.load('HeroDieRight\_DIE_001.png'),pygame.image.load('HeroDieRight\_DIE_002.png'), pygame.image.load('HeroDieRight\_DIE_003.png'),pygame.image.load('HeroDieRight\_DIE_004.png'), pygame.image.load('HeroDieRight\_DIE_005.png'), pygame.image.load('HeroDieRight\_DIE_006.png')]
    HeroDieLeft = [pygame.image.load('HeroDieLeft\_DIE_000.png'), pygame.image.load('HeroDieLeft\_DIE_001.png'), pygame.image.load('HeroDieLeft\_DIE_002.png'), pygame.image.load('HeroDieLeft\_DIE_003.png'), pygame.image.load('HeroDieLeft\_DIE_004.png'), pygame.image.load('HeroDieLeft\_DIE_005.png'), pygame.image.load('HeroDieLeft\_DIE_006.png')] 

    
    def __init__(self,x,y,width,height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 10
        
        self.isJump = False
        self.left = False
        self.right = False
        self.walkCount = 0
        self.jumpCount = 10
        self.standing = True

        self.slash = False
        self.slashNumber = 0
        
        self.hitbox = (self.x + 65, self.y + 25, 25, 80)
        self.hitboxAttack = (self.x, self.y + 60, 150, 20)

        self.hurt = False
        self.hurtNumber = -1
        self.health = 3

        self.visible = True
        self.die = False
        self.dieNumber = 0

        self.HitboxVisible = False
        

    def draw(self, win):
        self.hit()
        if self.visible:
            if self.walkCount + 1 >= 27:
                self.walkCount = 0

            if self.slashNumber + 1 >= 20:
                self.slashNumber = 0
                self.slash = False

            if self.slash == True:
                
                if self.left != True:
                    win.blit(self.swordSlashRight[self.slashNumber%7], (self.x,self.y))
                    self.slashNumber += 1

                     
                else:
                    win.blit(self.swordSlashLeft[self.slashNumber%7], (self.x,self.y))
                    self.slashNumber += 1
                    
            elif self.hurt == True:

                if self.left != True:
                    win.blit(self.HeroHurtRight[self.hurtNumber], (self.x,self.y))

                else:
                    win.blit(self.HeroHurtLeft[self.hurtNumber], (self.x,self.y))

            elif not(self.standing):
                if self.left:
                    win.blit(self.walkLeft[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1
                    
                elif self.right:
                    win.blit(self.walkRight[self.walkCount//7], (self.x,self.y))
                    self.walkCount +=1
                    
            else:
                if self.right:
                    number = (int(strftime("%S", gmtime()))) % 7
                    win.blit(self.charRight[number], (self.x,self.y))
                    
                else:
                    number = (int(strftime("%S", gmtime()))) % 7
                    win.blit(self.charLeft[number], (self.x,self.y))

        elif self.die == True and self.dieNumber < 7:

            if self.left != True:
                win.blit(self.HeroDieRight[self.dieNumber], (self.x,self.y))
                if self.dieNumber == 6:
                    self.die == False
            else:
                win.blit(self.HeroDieLeft[self.dieNumber], (self.x,self.y))
                if self.dieNumber == 6:
                   self.die == False

        else:
            if self.left != True:
                win.blit(self.HeroDieRight[6], (self.x,self.y))

            else:
                win.blit(self.HeroDieLeft[6], (self.x,self.y))
        
        self.hitbox = (self.x + 65, self.y + 25, 25, 80)
        self.hitboxAttack = (self.x, self.y + 60, 150, 20)
        if self.HitboxVisible == True:
            
            pygame.draw.rect(win, (255,0,0), self.hitbox, 2)
            pygame.draw.rect(win, (0,0,255), self.hitboxAttack, 2)
        
    def hit (self):

        if self.right == True and self.health == 0 and self.die == True:
            self.dieNumber += 1
                
        elif self.left == True and self.health == 0 and self.die == True:
           self.dieNumber += 1

        elif self.right == True and self.hurt == True:
            self.hurtNumber += 1
            
            if self.hurtNumber > 6:
                self.hurtNumber = -1
                self.hurt = False
                self.x = self.x - 30
                
                if self.health > 0:
                    self.health -= 1

                else:
                    self.visible = False
                    self.die = True
                
        elif self.left == True and self.hurt == True:
            self.hurtNumber += 1
            
            if self.hurtNumber > 6:
                self.hurtNumber = -1
                self.hurt = False
                self.x = self.x + 30
                
                if self.health > 0:
                    self.health -= 1

                else:
                    self.visible = False
                    self.die = True


    


class enemy(object):
    
    walkRight = [pygame.image.load('OrcRIGHT\RUN_000.png'), pygame.image.load('OrcRIGHT\RUN_001.png'), pygame.image.load('OrcRIGHT\RUN_002.png'), pygame.image.load('OrcRIGHT\RUN_003.png'), pygame.image.load('OrcRIGHT\RUN_004.png'), pygame.image.load('OrcRIGHT\RUN_005.png'), pygame.image.load('OrcRIGHT\RUN_006.png')]
    walkLeft = [pygame.image.load('OrcLEFT\RUN_000.png'), pygame.image.load('OrcLEFT\RUN_001.png'), pygame.image.load('OrcLEFT\RUN_002.png'), pygame.image.load('OrcLEFT\RUN_003.png'), pygame.image.load('OrcLEFT\RUN_004.png'), pygame.image.load('OrcLEFT\RUN_005.png'), pygame.image.load('OrcLEFT\RUN_006.png')]

    orcHurtLeft = [pygame.image.load('OrcHURTleft\HURT_000.png'), pygame.image.load('OrcHURTleft\HURT_001.png'), pygame.image.load('OrcHURTleft\HURT_002.png'), pygame.image.load('OrcHURTleft\HURT_003.png'), pygame.image.load('OrcHURTleft\HURT_004.png'), pygame.image.load('OrcHURTleft\HURT_005.png'), pygame.image.load('OrcHURTleft\HURT_006.png')]
    orcHurtRight = [pygame.image.load('OrcHURTright\HURT_000.png'), pygame.image.load('OrcHURTright\HURT_001.png'), pygame.image.load('OrcHURTright\HURT_002.png'), pygame.image.load('OrcHURTright\HURT_003.png'), pygame.image.load('OrcHURTright\HURT_004.png'), pygame.image.load('OrcHURTright\HURT_005.png'), pygame.image.load('OrcHURTright\HURT_006.png')]

    orcDieLeft = [pygame.image.load('OrcDieleft\DIE_000.png'), pygame.image.load('OrcDieleft\DIE_001.png'), pygame.image.load('OrcDieleft\DIE_002.png'), pygame.image.load('OrcDieleft\DIE_003.png'), pygame.image.load('OrcDieleft\DIE_004.png'), pygame.image.load('OrcDieleft\DIE_005.png'), pygame.image.load('OrcDieleft\DIE_006.png')]
    orcDieRight = [pygame.image.load('OrcDieright\DIE_000.png'), pygame.image.load('OrcDieright\DIE_001.png'), pygame.image.load('OrcDieright\DIE_002.png'), pygame.image.load('OrcDieright\DIE_003.png'), pygame.image.load('OrcDieright\DIE_004.png'), pygame.image.load('OrcDieright\DIE_005.png'), pygame.image.load('OrcDieright\DIE_006.png')]

    AxeSlashRight = [pygame.image.load('OrcAttackRight\ATTACK_000.png'), pygame.image.load('OrcAttackRight\ATTACK_001.png'), pygame.image.load('OrcAttackRight\ATTACK_002.png'), pygame.image.load('OrcAttackRight\ATTACK_003.png'), pygame.image.load('OrcAttackRight\ATTACK_004.png'), pygame.image.load('OrcAttackRight\ATTACK_005.png'), pygame.image.load('OrcAttackRight\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
    AxeSlashLeft = [pygame.image.load('OrcAttackLeft\ATTACK_000.png'), pygame.image.load('OrcAttackLeft\ATTACK_001.png'), pygame.image.load('OrcAttackLeft\ATTACK_002.png'), pygame.image.load('OrcAttackLeft\ATTACK_003.png'), pygame.image.load('OrcAttackLeft\ATTACK_004.png'),pygame.image.load('OrcAttackLeft\ATTACK_005.png'),pygame.image.load('OrcAttackLeft\ATTACK_006.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.path = [x, end]
        self.walkCount = 0
        self.vel = 5
        self.hitbox = (self.x + 60, self.y + 5, 50, 50)
        self.health = 3
        self.Troll = False
        
        self.visible = True
        self.die = False
        self.dieNumber = -1
        
        self.hurt = False
        self.hurtNumber = -1

        self.attack = False
        self.attackNumber = -1

        self.HitboxVisible = False

    def draw(self, win):
        self.move()
        if self.visible :
            
            if self.walkCount + 1 >= 33:
                self.walkCount = 0
            
            if self.vel > 0:
                if self.hurt == True:
                    win.blit(self.orcHurtRight[self.hurtNumber], (self.x,self.y))
                    
                elif self.attack == True:
                    if self.Troll == True:
                        win.blit(self.AxeSlashRight[self.attackNumber], (self.x,self.y - 80))

                    else:
                        win.blit(self.AxeSlashRight[self.attackNumber], (self.x,self.y - 45))

                elif  self.health == 0 and self.die == True and self.dieNumber < 7 :
                    win.blit(self.orcDieRight[self.dieNumber], (self.x,self.y))
                    self.dieNumber += 1
                    if self.dieNumber == 6:
                        self.dieNumber = -1
                        self.visible = False
                
                else:
                    win.blit(self.walkRight[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1
            else:
                if self.hurt == True:
                    win.blit(self.orcHurtLeft[self.hurtNumber], (self.x,self.y))
                    
                    
                elif self.attack == True:
                    
                    if self.Troll == True:
                        win.blit(self.AxeSlashLeft[self.attackNumber], (self.x,self.y - 80))
                        
                    else:
                        win.blit(self.AxeSlashLeft[self.attackNumber], (self.x,self.y - 45))

                elif  self.health == 0 and self.die == True and self.dieNumber < 7 :
                    win.blit(self.orcDieLeft[self.dieNumber], (self.x,self.y))
                    self.dieNumber += 1
                    
                    if self.dieNumber == 6:
                        self.dieNumber = -1
                        self.visible = False
                    
                else:
                    win.blit(self.walkLeft[self.walkCount//7], (self.x,self.y))
                    self.walkCount += 1

            if self.Troll == False:
                self.hitbox = (self.x + 60, self.y + 5, 50, 50)
                
                if self.HitboxVisible == True:
                    
                    pygame.draw.rect(win, (255,0,0), self.hitbox,2)
                

            else:
                self.hitbox = (self.x + 95, self.y + 25, 85, 150)
                
                if self.HitboxVisible == True:
                    pygame.draw.rect(win, (255,0,0), self.hitbox,2)

        else:
            
            if self.vel > 0:
                win.blit(self.orcDieRight[self.dieNumber], (self.x,self.y))

            else:
                win.blit(self.orcDieLeft[self.dieNumber], (self.x,self.y))
            

        
            
    def move(self):
        if self.visible:
            
            if self.vel > 0:
                
                if self.x < self.path[1] + self.vel:
                    
                    if self.hurt == True and self.hurtNumber < 6:
                        self.hurtNumber +=1
                        
                        if self.Troll == True:
                            pass
                        
                        else:
                            self.x -= 10
                        
                    elif self.attack == True and self.attackNumber < 6:
                        self.attackNumber +=1
                        
                    else:
                        self.hurtNumber = -1
                        self.attackNumber = -1
                        self.hurt = False
                        self.attack = False
                        self.x += self.vel
                        
                    
                else:
                    self.vel = self.vel * -1
                    self.x += self.vel
                    self.walkCount = 0
                    
                    
            else:
                if self.x > self.path[0] - self.vel:
                    
                    if self.hurt == True and self.hurtNumber < 6:
                        self.hurtNumber+=1
                        
                        if self.Troll == True:
                            pass
                        
                        else:
                            self.x += 10
                        
                    elif self.attack == True and self.attackNumber < 6:
                        self.attackNumber +=1
                        
                    else:
                        self.hurtNumber = -1
                        self.attackNumber = -1
                        self.hurt = False
                        self.attack = False
                        self.x += self.vel
                    
                else:
                    self.vel = self.vel * -1
                    self.x += self.vel
                    self.walkCount = 0
                    


    def hit(self):
        
        if self.health > 0:
            self.health -= 1
            self.hurt = True
            
        else:
            self.die = True
            
        


def redrawGameWindow():
    win.blit(bg, (0,0))
    text = font.render('Health: '+ str(man.health), 1, (0,0,0))
    win.blit(text, (50, 40))
    text = font.render('Score: '+ str(score), 1, (0,0,0))
    win.blit(text, (1000, 40))
    man.draw(win)
    enemy1.draw(win)
    enemy2.draw(win)
    enemy3.draw(win)
    if man.HitboxVisible == True:
        enemy5.draw(win)
        
        if enemy5.die == False:  
            enemy5.visible = True
            
        else:
            pass
        
    elif enemy1.visible == False and enemy2.visible == False and enemy3.visible == False and man.HitboxVisible == False:
        enemy5.draw(win)
        
        if enemy5.die == False:  
            enemy5.visible = True
            
        else:
            pass
    
    
    pygame.display.update()


#Troll stuff:
enemy5 = enemy(-400, 500, 64, 64, 1000)
enemy5.Troll = True
enemy5.health = 200
enemy5.orcDieRight = [pygame.image.load('TrollDieRight\DIE_000.png'), pygame.image.load('TrollDieRight\DIE_001.png'), pygame.image.load('TrollDieRight\DIE_002.png'), pygame.image.load('TrollDieRight\DIE_003.png'), pygame.image.load('TrollDieRight\DIE_004.png'), pygame.image.load('TrollDieRight\DIE_005.png'), pygame.image.load('TrollDieRight\DIE_006.png')]
enemy5.orcDieLeft = [pygame.image.load('TrollDieLeft\DIE_000.png'), pygame.image.load('TrollDieLeft\DIE_001.png'), pygame.image.load('TrollDieLeft\DIE_002.png'), pygame.image.load('TrollDieLeft\DIE_003.png'), pygame.image.load('TrollDieLeft\DIE_004.png'), pygame.image.load('TrollDieLeft\DIE_005.png'), pygame.image.load('TrollDieLeft\DIE_006.png')]
enemy5.AxeSlashRight = [pygame.image.load('TrollAttackRight\ATTACK_000.png'), pygame.image.load('TrollAttackRight\ATTACK_001.png'), pygame.image.load('TrollAttackRight\ATTACK_002.png'), pygame.image.load('TrollAttackRight\ATTACK_003.png'), pygame.image.load('TrollAttackRight\ATTACK_004.png'), pygame.image.load('TrollAttackRight\ATTACK_005.png'), pygame.image.load('TrollAttackRight\ATTACK_006.png'), pygame.image.load('Hero_ATTACK_Right\ATTACK_006.png')]
enemy5.AxeSlashLeft = [pygame.image.load('TrollAttackLeft\ATTACK_000.png'), pygame.image.load('TrollAttackLeft\ATTACK_001.png'), pygame.image.load('TrollAttackLeft\ATTACK_002.png'), pygame.image.load('TrollAttackLeft\ATTACK_003.png'), pygame.image.load('TrollAttackLeft\ATTACK_004.png'),pygame.image.load('TrollAttackLeft\ATTACK_005.png'),pygame.image.load('TrollAttackLeft\ATTACK_006.png')]
enemy5.orcHurtLeft = [pygame.image.load('TrollHurtLeft\HURT_000.png'), pygame.image.load('TrollHurtLeft\HURT_001.png'), pygame.image.load('TrollHurtLeft\HURT_002.png'), pygame.image.load('TrollHurtLeft\HURT_003.png'), pygame.image.load('TrollHurtLeft\HURT_004.png'), pygame.image.load('TrollHurtLeft\HURT_005.png'), pygame.image.load('TrollHurtLeft\HURT_006.png')]
enemy5.orcHurtRight = [pygame.image.load('TrollHurtRight\HURT_000.png'), pygame.image.load('TrollHurtRight\HURT_001.png'), pygame.image.load('TrollHurtRight\HURT_002.png'), pygame.image.load('TrollHurtRight\HURT_003.png'), pygame.image.load('TrollHurtRight\HURT_004.png'), pygame.image.load('TrollHurtRight\HURT_005.png'), pygame.image.load('TrollHurtRight\HURT_006.png')]
enemy5.walkRight = [pygame.image.load('TrollRunRight\RUN_000.png'), pygame.image.load('TrollRunRight\RUN_001.png'), pygame.image.load('TrollRunRight\RUN_002.png'), pygame.image.load('TrollRunRight\RUN_003.png'), pygame.image.load('TrollRunRight\RUN_004.png'), pygame.image.load('TrollRunRight\RUN_005.png'), pygame.image.load('TrollRunRight\RUN_006.png')]
enemy5.walkLeft = [pygame.image.load('TrollRunLeft\RUN_000.png'), pygame.image.load('TrollRunLeft\RUN_001.png'), pygame.image.load('TrollRunLeft\RUN_002.png'), pygame.image.load('TrollRunLeft\RUN_003.png'), pygame.image.load('TrollRunLeft\RUN_004.png'), pygame.image.load('TrollRunLeft\RUN_005.png'), pygame.image.load('TrollRunLeft\RUN_006.png')]
enemy5.visible = False
enemy5.vel = 4

font = pygame.font.SysFont('comicsans', 30, True, True)
man = player(500, 500, 64,64)

enemy1 = enemy(-50, 500, 64, 64, 1000)
enemy2 = enemy(-10, 550, 64, 64, 1000)
enemy3 = enemy(60, 560, 64, 64, 1000)
enemy4 = enemy(300, 600, 64, 64, 1000)



display_instructions = True
instruction_page = 1
run = True
while run and display_instructions:
    
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            done = True
            
        if event.type == pygame.MOUSEBUTTONDOWN:
            instruction_page += 1
            
            if instruction_page == 2:
                display_instructions = False
 
    # Set the screen background
    screen.fill(BLACK)
 
    if instruction_page == 1:
        # Draw instructions, page 1
        # This could also load an image created in another program.
        # That could be both easier and more flexible.
 
        text = font.render("Moe's Game", True, WHITE)
        screen.blit(text, [10, 10])#where to be positioned

        text = font.render('Press "q" if you want to exit the Game', True, WHITE)
        screen.blit(text, [10, 50])#where to be positioned
 
        text = font.render("Welcome to the Middle ages in MOLANDIA.", True, WHITE)
        screen.blit(text, [350, 300])

        text = font.render("Press mousepad to continue.", True, WHITE)
        screen.blit(text, [425, 450])
 
 
    # Limit to 60 frames per second
    clock.tick(60)
 
    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()


FirstTimeRun = True



'''
Main Loop
'''
while run:
    clock.tick(27)
    

    if FirstTimeRun == True:       
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('SLAY!!!', 1, (255,0,0))
            win.blit(text, [470, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(7)
                i += 1
                FirstTimeRun = False
                
        
    if enemy1.visible != False and enemy1.die != True:
        
        if man.die == False:
            
            if man.hitbox[1] < man.hitbox[1] + enemy1.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy1.hitbox[1]:
                
                if man.hitbox[0] < enemy1.hitbox[0] + enemy1.hitbox[2] and man.hitbox[0] + man.hitbox[2] > enemy1.hitbox[0]:
                    enemy1.attack = True
                    man.hurt = True
                    score -= 5


    if enemy2.visible != False and enemy2.die != True:
        
        if man.die == False:
            
            if man.hitbox[1] < man.hitbox[1] + enemy2.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy2.hitbox[1]:
                
                if man.hitbox[0] + man.hitbox[2] > enemy2.hitbox[0] and man.hitbox[0] < enemy2.hitbox[0] + enemy2.hitbox[2]:
                    enemy2.attack = True
                    man.hurt = True
                    score -= 5

    if enemy3.visible != False and enemy3.die != True:
        
        if man.die == False:
            
            if man.hitbox[1] < man.hitbox[1] + enemy3.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy3.hitbox[1]:
                
                if man.hitbox[0] + man.hitbox[2] > enemy3.hitbox[0] and man.hitbox[0] < enemy3.hitbox[0] + enemy3.hitbox[2]:                    
                    enemy3.attack = True
                    man.hurt = True
                    score -= 5

    if enemy4.visible != False and enemy4.die != True:
        
        if man.die == False:
            
            if man.hitbox[1] < man.hitbox[1] + enemy4.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy4.hitbox[1]:
                
                if man.hitbox[0] + man.hitbox[2] > enemy4.hitbox[0] and man.hitbox[0] < enemy4.hitbox[0] + enemy4.hitbox[2]:
                    enemy4.attack = True
                    man.hurt = True
                    score -= 5

    if enemy5.visible != False and enemy5.die != True:
        
        if man.die == False:
            
            if man.hitbox[1] < man.hitbox[1] + enemy5.hitbox[3] and man.hitbox[1] + man.hitbox[3] > enemy5.hitbox[1]:
                
                if man.hitbox[0] + man.hitbox[2] > enemy5.hitbox[0] and man.hitbox[0] < enemy5.hitbox[0] + enemy5.hitbox[2]:
                    enemy5.attack = True
                    man.hurt = True
                    score -= 5

    
        
    for event in pygame.event.get():
        
        if event.type == pygame.QUIT:
            run = False
            
    keys = pygame.key.get_pressed()

    if keys[pygame.K_x]:
        man.slash = True

        if man.die == False:
            
            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy1.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy1.hitbox[1]:
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy1.hitbox[0] and man.hitboxAttack[0] < enemy1.hitbox[0] + enemy1.hitbox[2]:
                    enemy1.hit()

                    if enemy1.health == 0:
                        pass
                    
                    else:
                        score += 1

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy2.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy2.hitbox[1]:
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy2.hitbox[0] and man.hitboxAttack[0] < enemy2.hitbox[0] + enemy2.hitbox[2]:
                    enemy2.hit()
                    
                    if enemy2.health == 0:
                        pass
                    
                    else:
                        score += 1

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy3.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy3.hitbox[1]:
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy3.hitbox[0] and man.hitboxAttack[0] < enemy3.hitbox[0] + enemy3.hitbox[2]:
                    enemy3.hit()

                    if enemy3.health == 0:
                        pass
                    
                    else:
                        score += 1
                        
            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy4.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy4.hitbox[1]:
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy4.hitbox[0] and man.hitboxAttack[0] < enemy4.hitbox[0] + enemy4.hitbox[2]:
                    enemy4.hit()

                    if enemy4.health == 0:
                        pass
                    
                    else:
                        score += 1

            if man.hitboxAttack[1] < man.hitboxAttack[1] + enemy5.hitbox[3] and man.hitboxAttack[1] + man.hitboxAttack[3] > enemy5.hitbox[1]:
                
                if man.hitboxAttack[0] + man.hitboxAttack[2] > enemy5.hitbox[0] and man.hitboxAttack[0] < enemy5.hitbox[0] + enemy5.hitbox[2]:
                    enemy5.hit()

                    if enemy5.health == 0:
                        pass
                    
                    else:
                        score += 1


    if keys[pygame.K_LEFT] and man.x >  man.vel:
        man.x -= man.vel
        man.left = True
        man.right = False
        man.standing = False
        
    elif keys[pygame.K_RIGHT] and man.x < 1100 - man.width - man.vel:
        man.x += man.vel
        man.right = True
        man.left = False
        man.standing = False

    elif keys[pygame.K_UP] and man.y > man.vel and man.y > 550 - man.width - man.vel:
        man.y -= man.vel
        
        if man.right == True:
            man.right = True
            man.left = False
            man.standing = False

        else:
            man.left = True
            man.right = False
            man.standing = False
        
    elif keys[pygame.K_DOWN] and man.y > man.vel and man.y < 670 - man.width - man.vel:
        man.y += man.vel
        
        if man.right == True:
            man.right = True
            man.left = False
            man.standing = False

        else:
            man.left = True
            man.right = False
            man.standing = False

    elif keys[pygame.K_p]:
        
        for i in (enemy1,enemy2,enemy3,enemy4,enemy5,man):

            if i.visible == False:
                i.health = 10
                i.visible = True
                i.die = False
                i.HitboxVisible = True

    elif keys[pygame.K_q]:
        if score <= 0:
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('You can do better', 1, (255,0,0))
            win.blit(text, [280, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(3000)
                i += 1
                pygame.quit()
        else:
            font1 = pygame.font.SysFont('comicsans', 100)
            text = font1.render('Well done', 1, (255,0,0))
            win.blit(text, [470, 300])
            pygame.display.update()
            i = 0
            
            while i < 300:
                pygame.time.delay(3000)
                i += 1
                pygame.quit()
        
        
    
    else:
        man.standing = True
        man.walkCount = 0

    if not(man.isJump):
        if keys[pygame.K_SPACE]:
            man.isJump = True
            man.right = False
            man.left = False
            man.walkCount = 0
    else:
        if man.jumpCount >= -10:
            neg = 1
            
            if man.jumpCount < 0:
                neg = -1
                
            man.y -= (man.jumpCount ** 2) * 0.5 * neg
            man.jumpCount -= 1
            
        else:
            man.isJump = False
            man.jumpCount = 10
            
    redrawGameWindow()

pygame.quit()


